#ifndef Balls_hpp
#define Balls_hpp

#include <vector>
#include "cinder/gl/gl.h"
#include "cinder/Xml.h"
#include "cinder/Color.h"
#include <boost/circular_buffer.hpp>

#include "FileWatch.h"
#include "GameWorld.h"
#include "Contour.h"
#include "PureDataNode.h"
#include "MIDIInput.h"

using namespace ci;
using namespace ci::app;
using namespace std;

class Ball {
	
public:
	Ball() {
		mCollideWithContours	= 1;
		mPausePhysics			= 0;
		mCapVelocity			= 1;
	}
	
	vec2 mLoc ;
	vec2 mLastLoc ;
	vec2 mAccel ;
	
	float mRadius ;
	ColorAf mColor ;
	ColorAf mRibbonColor=ColorAf(0,0,0,0) ;
	
	void setLoc( vec2 l ) { vec2 v=getVel(); mLoc=l; setVel(v); }
	void setVel( vec2 v ) { mLastLoc = mLoc - v ; }
	vec2 getVel() const { return mLoc - mLastLoc ; }
	
	void  setMass( float m ) { mMass = m ; }
	float getMass() const { return mMass ; }
	float getInvMass() const { return 1.f / getMass() ; }
	
	void noteSquashImpact( vec2 directionAndMagnitude )
	{
		if ( length(directionAndMagnitude) > length(mSquash) ) mSquash = directionAndMagnitude ;
	}

	vec2  mSquash ;
	

	unsigned int mCollideWithContours : 1;
	unsigned int mPausePhysics		  : 1;
	unsigned int mCapVelocity		  : 1;
	uint32_t	 mCollisionMask				= 1; 
	

	boost::circular_buffer<vec2> mHistory;

	class UserData {
  	  public:
		virtual ~UserData() {}
	};	
	std::shared_ptr<UserData> mUserData;
	
private:
	float	mMass = 1.f ; 

};


class BallWorld : public GameWorld
{
public:
	
	BallWorld();
	~BallWorld();
	
	string getSystemName() const override { return "BallWorld"; }
	
	void setParams( XmlTree ) override;
	void updateVision( const Vision::Output& c, Pipeline& ) override { setContours(c.mContours); }
	
	void gameWillLoad() override;
	void update() override;
	void prepareToDraw() override;
	void draw( DrawType ) override;
	
	Ball& newRandomBall( vec2 loc );
	void clearBalls() { mBalls.clear(); }
	void eraseBall ( int index );
	void eraseBalls( std::set<size_t> indices );
	
	float getBallDefaultRadius() const { return mBallDefaultRadius ; }
	int   getTargetBallCount() const;
	virtual void worldBoundsPolyDidChange() override;
	
	vec2 resolveCollisionWithContours		( vec2 p, float r, const Ball* b=0 );
	vec2 resolveCollisionWithInverseContours( vec2 p, float r, const Ball* b=0 );
	void mouseClick( vec2 p ) override { newRandomBall(p) ; }
	void keyDown( KeyEvent ) override;
	void drawMouseDebugInfo( vec2 ) override;
	
	void setNumBalls( int );
	
	vector<Ball>& getBalls() { return mBalls; }
	const vector<Ball>& getBalls() const { return mBalls; }
	
	vec2 getDenoisedBallVel( const Ball& ) const; 
	
	ContourVector& getContours() { return mContours; }
	const ContourVector& getContours() const { return mContours; }

	struct BallBallCollision {
	public:
		BallBallCollision( int a=-1, int b=-1 ) { mBallIndex[0]=a; mBallIndex[1]=b; }
		int mBallIndex[2];
	};
	typedef vector<BallBallCollision> BallBallCollisionVec;
	
	struct BallContourCollision {
	public:
		BallContourCollision( int a, int b, vec2 pt )
			: mBallIndex(a)
			, mContourIndex(b)
			, mPt(pt) {}

		BallContourCollision() : BallContourCollision(-1,-1,vec2(0.f)){} 

		int mBallIndex;
		int mContourIndex;
		vec2 mPt;
	};
	typedef vector<BallContourCollision> BallContourCollisionVec;

	struct BallWorldCollision {
	public:
		BallWorldCollision( int a=-1, vec2 pt=vec2(0.f) ) { mBallIndex=a; mPt=pt; }
		int mBallIndex;
		vec2 mPt;
	};
	typedef vector<BallWorldCollision> BallWorldCollisionVec;

	const BallBallCollisionVec&		getBallBallCollisions() const { return mBallBallCollisions; }
	const BallContourCollisionVec&	getBallContourCollisions() const { return mBallContourCollisions; }
	const BallWorldCollisionVec&	getBallWorldCollisions() const { return mBallWorldCollisions; }
	
	int getNumIntegrationSteps() const { return mNumIntegrationSteps; }

	void drawBalls( DrawType, gl::GlslProgRef=0 ) const;
	void drawRibbons( DrawType ) const;

	cipd::PureDataNodeRef mPd;
	cipd::PatchRef	      mPatch;
	virtual void setupSynthesis();
	virtual void updateSynthesis();
		
protected:

	void setContours( const ContourVec& contours, ContourVec::Filter filter=0 ) { mContours = contours; mContourFilter=filter; }
	
	int getBallIndex( const Ball& b ) const;
	
	virtual void onBallBallCollide			( const Ball&, const Ball& );
	virtual void onBallContourCollide		( const Ball&, const Contour&, vec2 );
	virtual void onBallWorldBoundaryCollide	( const Ball&, vec2 );
	
	void maybeUpdateBallPopulationWithDesiredDensity();
	
	int		mNumIntegrationSteps	= 1;	
	float	mBallDensity			= -1.f; 
	float	mBallDefaultRadius		= 8.f *  .5f ;
	float	mBallDefaultMaxRadius	= 8.f * 4.f ;
	float	mBallMaxVel				= 8.f ;
	ColorAf mBallDefaultColor		= ColorAf::hex(0xC62D41);
	ColorAf mBallDefaultRibbonColor	= ColorAf(1,1,1,1);
	float   mBallContourImpactNormalVelImpulse = .0f;
	float	mBallContourCoeffOfRestitution = 1.f;
	float	mBallContourFrictionlessCoeff = 1.f;
	
	bool	mRibbonEnabled   = false;
	int		mRibbonMaxLength = 32;
	int		mRibbonSampleRate= 1;
	float	mRibbonRadiusScale = .9f;
	float	mRibbonRadiusExp   = .5f;
	float	mRibbonAlphaScale  = .5f;
	float	mRibbonAlphaExp    = .5f;
	
	int  getRibbonMaxLength() const { return mRibbonEnabled ? mRibbonMaxLength : 0; }
	void accumulateBallHistory();
	void updateBallsWithRibbonParams();

	mat4 getBallTransform( const Ball& b, mat4* fixNormalMatrix=0 ) const;
	
private:	
	BallBallCollisionVec	mBallBallCollisions;
	BallContourCollisionVec	mBallContourCollisions;
	BallWorldCollisionVec	mBallWorldCollisions;

	int mLastNumIntegrationSteps=1;
	
	void scaleBallVelsForIntegrationSteps( int oldSteps, int newSteps );
	void updatePhysics();

	vec2 unlapEdge( vec2 p, float r, const Contour& poly, const Ball* b=0 );
	vec2 unlapHoles( vec2 p, float r, ContourKind kind, const Ball* b=0 );
	
	void resolveBallContourCollisions();
	void resolveBallCollisions() ;

	ContourVector		mContours;
	ContourVector::Filter mContourFilter;
	vector<Ball>		mBalls ;

	void drawImmediate( bool lowPoly ) const;
	TriMeshRef getTriMeshForBalls() const;
	TriMeshRef getTriMeshForRibbons() const;
	TriMeshRef mBallMesh;
	TriMeshRef mRibbonMesh;
	
	gl::GlslProgRef mCircleShader;

	FileWatch mFileWatch;
	MIDIInput mMidiInput;

} ;

#endif /* Balls_hpp */